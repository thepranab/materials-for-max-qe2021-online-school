# LaTeX2HTML 2019 (Released January 1, 2019)
# Associate images original text with physical files.


$key = q/includegraphics[width=5cm]{..slash..slash..slash..slashDocslashquantum_espresso.pdf};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG STYLE=""
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[width=5cm]{../../../../Doc/quantum_espresso.pdf}">|; 

1;

