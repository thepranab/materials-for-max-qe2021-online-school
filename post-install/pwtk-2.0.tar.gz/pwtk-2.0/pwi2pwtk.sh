#!/bin/sh

# Usage: pwi2pwtk.sh pw.x-input-file
# Purpose: convert pw.x-input-file file to PWTK script file

head=prefix
if test $# -lt 1; then
    input=-
else
    input=$1
    head=${input%.xsf*}
fi


cat $input | awk '
BEGIN {
  inside_namelist=0;
  inside_card=0;
}

# namelists

toupper($1) ~ /^&CONTROL$|^&SYSTEM$|^&ELECTRONS$|^&IONS$|^&CELL$|^&FCP$/ { 

   inside_namelist=1;
   split(toupper($1), f, "&");
   printf "\n%s %s\n", f[2], "{";
   next;
}

# end-of-namelist

$1 ~ /^ *\/ *$|^ *\&end *$/ { print "}"; next; }

# cards (flag-less)

$1 ~ /^ATOMIC_SPECIES|^CLIMBING_IMAGES|^CONSTRAINTS|^COLLECTIVE_VARS|^OCCUPATIONS|^ATOMIC_FORCES/ {
   if (inside_card == 1) print "}";

   inside_card=1;

   printf "\n%s %s\n", $1, "{";
   next;
}

# cards (with flags)

$1 ~ /^ATOMIC_POSITIONS|^K_POINTS|^CELL_PARAMETERS/ {

   if (inside_card == 1) print "}";

   inside_card=1;

   if (NF==1) f2="{}";
   else f2=$2;

   printf "\n%s %s %s\n", $1, f2, "{";
   next;
}

/a*/ {
   if ( (inside_namelist || inside_card) && $0 != "" && $1 !~ /^[!#]/) { print; }
}

END {
   print "}";
}
'
